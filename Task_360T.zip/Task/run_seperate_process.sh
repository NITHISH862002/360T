#!/bin/bash

# Compile the Java files
javac -d bin src/main/java/com/player/PlayerOpponent.java src/main/java/com/player/PlayerInitiator.java src/main/java/com/player/logging/LogMessages.java

# Start Player 2 (Server) in a new terminal window
gnome-terminal --command="java -cp bin com.player.PlayerOpponent"

# Give the server some time to start
sleep 2

# Start Player 1 (Initiator(Client)) in a new terminal window
gnome-terminal --command="java -cp bin com.player.PlayerInitiator"