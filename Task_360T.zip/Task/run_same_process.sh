#!/bin/bash

# Compile the Java files
javac -d bin src/main/java/com/player/Player.java src/main/java/com/player/logging/LogMessages.java

# Start Player (Server) in a new terminal window
gnome-terminal --command="java -cp bin com.player.Player"