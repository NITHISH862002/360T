# Communication between players 

A simple Java application that demonstrates a client-server communication using sockets.

## Overview

This application consists of two main components:

* A server that listens for incoming connections and responds to client requests.
* A client that connects to the server and sends requests.

## Features

* Client-server communication using sockets.
* Supports multiple client connections.
* Handles client requests and sends responses.

## Requirements

* Java 8 or later.
* A properties file named `player.properties` in the same directory as the application.

## Configuration

The application uses a properties file to configure the server address and port. The properties file should contain the following entries:

* `player.host`: The address of the server (e.g. `localhost`).
* `player.port`: The port number of the server (e.g. `12345`).

## Usage

1. To run the application  in linux in same process click the  `start_same_process.sh` batch file and to run the application in different process `start_seperate_process.sh` file.
2. To run the application  in windows in same process click the  `start_same_process.bat` batch file and to run the application in different process `start_seperate_process.bat` file.
3. The client will connect to the server and prompt the user to enter a message.
4. The server will respond to the client request and send a response.

## Notes

* This is a simple example application and should not be used in production without further testing and modification.
* The application uses a simple socket-based communication protocol and does not include any error handling or security features.


## Author
[Nithish Anand B]
[LinkedIn](https://in.linkedin.com/in/nithishanandb)