package com.player;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.player.logging.LogMessages;

/**
 * A server that communicates with a client through a socket connection.
 *
 * This class represents a server that listens for incoming connections from a
 * client, reads messages from the client, and sends replies back to the client.
 *
 * The communication session continues until either 10 messages have been
 * received from the client or 10 messages have been sent to the client.
 *
 * @author Nithish Anand
 */
public class PlayerOpponent {
	/**
	 * The logger instance for this class.
	 */
	private static final Logger logger = Logger.getLogger(PlayerOpponent.class.getName());

	/**
	 * The server socket that listens for incoming connections.
	 */
	private ServerSocket serverSocket;

	/**
	 * Constructs a new `PlayerServer` instance that listens on the specified port.
	 *
	 * @param port the port number to listen on
	 */
	public PlayerOpponent(int port) {
		try {
			serverSocket = new ServerSocket(port);
			logger.log(Level.INFO,
					"Player 2(server) is online and waiting for messages from client...");
		} catch (IOException e) {
			logger.log(Level.SEVERE, e.getMessage());

		}
	}

	/**
	 * Initiates a communication session with a client.
	 *
	 * This method establishes a connection with a client, reads messages from the
	 * client, and sends replies back to the client. The communication session
	 * continues until either 10 messages have been received from the client or 10
	 * messages have been sent to the client.
	 *
	 * @throws IOException if an I/O error occurs during the communication session
	 */
	public void start() {
		try (Socket socket = serverSocket.accept();
				BufferedReader in = new BufferedReader(
						new InputStreamReader(socket.getInputStream()));
				PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
				BufferedReader userInput = new BufferedReader(new InputStreamReader(System.in))) {
			String receivedMessage;
			int receivedCount = 0;
			int sentCount = 0;
			while (receivedCount < 10 && sentCount < 10) {
				if ((receivedMessage = in.readLine()) != null) {
					logger.log(Level.INFO, LogMessages.MESSAGE_RECEIVED_FROM_CLIENT.getValue()+receivedMessage);
					receivedCount++;
					// Get reply message from user input
					logger.log(Level.INFO, LogMessages.ENTER_REPLY_MESSAGE.getValue());
					String replyMessage = userInput.readLine();
					String fullReply = String.format(
							"client=%s server=%s (Client count: %d, Server count: %d)",
							receivedMessage, replyMessage, receivedCount, sentCount);
					out.println(fullReply);
					sentCount++;
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * The main entry point for the `PlayerServer` application.
	 *
	 * Creates a new `PlayerServer` instance that listens on port 12345 and starts
	 * the communication session.
	 *
	 * @param args command-line arguments (not used)
	 */
	public static void main(String[] args) {
		Properties props = null;
		int port=12345;
		try (FileReader reader = new FileReader("player.properties")) {
			props = new Properties();
			props.load(reader);
			port = Integer.parseInt(props.getProperty("player.port"));

		} catch (IOException e) {

		}
		PlayerOpponent server = new PlayerOpponent(port);
		server.start();
	}
}