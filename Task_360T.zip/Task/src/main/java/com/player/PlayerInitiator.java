package com.player;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Properties;
import java.util.Scanner;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import com.player.logging.LogMessages;

/**
 * Represents a client that connects to a server and initiates a communication
 * loop.
 *
 * This class creates a socket connection to the specified host and port, and
 * then enters a loop where it sends user-input messages to the server and
 * receives responses.
 *
 * @author Nithish Anand
 */
public class PlayerInitiator {

	/**
	 * The logger instance for this class.
	 */
	private static final Logger logger = Logger.getLogger(PlayerInitiator.class.getName());

	/**
	 * The host to connect to.
	 */
	private final String host;

	/**
	 * The port to connect to.
	 */
	private final int port;

	/**
	 * Constructs a new PlayerClient instance with the specified host and port.
	 *
	 * @param host the host to connect to
	 * @param port the port to connect to
	 */
	public PlayerInitiator(Properties props) {
		this.host = props.getProperty("player.host");
		this.port = Integer.parseInt(props.getProperty("player.port"));

		try {
			FileHandler fileHandler = new FileHandler(props.getProperty("log.file.name"), true);
			fileHandler.setFormatter(new SimpleFormatter());
			logger.addHandler(fileHandler);
			logger.setUseParentHandlers(true);// Enable logging to console
		} catch (IOException e) {
			logger.log(Level.SEVERE, LogMessages.FAILED_TO_INITIALIZE_LOGGER_FILEHANDLER.getValue(),
					e);
		}
	}

	/**
	 * Establishes a connection to a server and initiates a communication loop.
	 *
	 * This method creates a socket connection to the specified host and port, and
	 * then enters a loop where it sends user-input messages to the server and
	 * receives responses. The loop continues until 10 messages have been sent and
	 * received, or an error occurs.
	 *
	 * @throws IOException if an error occurs while connecting to the server or
	 *                     communicating with the server
	 */
	public void start() {
		try (Socket socket = new Socket(host, port);
				PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
				BufferedReader in = new BufferedReader(
						new InputStreamReader(socket.getInputStream()))) {

			Scanner scanner = new Scanner(System.in);
			int sentCount = 0;
			int receivedCount = 0;

			while (sentCount < 10 && receivedCount < 10) {
				logger.log(Level.INFO, LogMessages.ENTER_MESSAGE.getValue());
				String message = scanner.nextLine();
				out.println(message);
				sentCount++;
				logger.log(Level.INFO, LogMessages.SENT_TO_SERVER.getValue() + message);

				String response = in.readLine();
				logger.log(Level.INFO, LogMessages.RECEIVED_FROM_SERVER.getValue() + response);
				receivedCount++;
			}

			logger.info(LogMessages.COMMUNICATION_COMPLETED_SHUTTING_DOWN.getValue());
			scanner.close();
		} catch (IOException e) {
			logger.log(Level.SEVERE,
					LogMessages.ERROR_CONNECTING_SERVER.getValue() + e.getMessage());

		}
	}

	/**
	 * The main entry point for the application.
	 *
	 * Creates a new PlayerClient instance with the specified host and port, and
	 * then starts the communication loop.
	 *
	 * @param args command-line arguments (not used)
	 */
	public static void main(String[] args) {
		Properties props = null;
		try (FileReader reader = new FileReader("player.properties")) {
			props = new Properties();
			props.load(reader);

		} catch (IOException e) {
			logger.log(Level.SEVERE,
					LogMessages.ERROR_LOADING_PROPERTIES_FILE.getValue() + e.getMessage());
			System.exit(0);

		}
		PlayerInitiator client = new PlayerInitiator(props);
		client.start();

	}
}
