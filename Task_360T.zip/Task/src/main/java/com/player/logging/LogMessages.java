package com.player.logging;

public enum LogMessages {
	FAILED_TO_INITIALIZE_LOGGER_FILEHANDLER("Failed to initialize logger FileHandler. "),
	SENT_TO_SERVER("Sent to server: "), RECEIVED_FROM_SERVER("Received from server: "),
	COMMUNICATION_COMPLETED_SHUTTING_DOWN("Communication complete. Shutting down."),
	ERROR_CONNECTING_SERVER("Error connecting to server."),
	MESSAGE_RECEIVED_FROM_CLIENT("Message received from client:"), ENTER_MESSAGE("Enter Message: "),
	ENTER_REPLY_MESSAGE("Enter reply message: "),
	ERROR_LOADING_PROPERTIES_FILE("Error loading properties file: ")

	;

	private String value;

	LogMessages(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}
}
