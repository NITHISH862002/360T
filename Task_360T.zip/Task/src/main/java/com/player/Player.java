package com.player;


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Properties;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.player.logging.LogMessages;

public class Player {
    private static final Logger logger = Logger.getLogger(Player.class.getName());
    
    private ServerSocket serverSocket;
    private Socket clientSocket;

    public void startServer(int port) {
        try {
            serverSocket = new ServerSocket(port);
            logger.log(Level.INFO, "Server is online and waiting for messages from client...");
            
            try (Socket socket = serverSocket.accept();
                 BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                 PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
                 BufferedReader userInput = new BufferedReader(new InputStreamReader(System.in))) {
                String receivedMessage;
                int receivedCount = 0;
                int sentCount = 0;
                while (receivedCount < 10 && sentCount < 10) {
                    if ((receivedMessage = in.readLine()) != null) {
                        logger.log(Level.INFO, LogMessages.MESSAGE_RECEIVED_FROM_CLIENT.getValue() + receivedMessage);
                        receivedCount++;
                        logger.log(Level.INFO, LogMessages.ENTER_REPLY_MESSAGE.getValue());
                        String replyMessage = userInput.readLine();
                        String fullReply = String.format(
                                "client=%s server=%s (Client count: %d, Server count: %d)",
                                receivedMessage, replyMessage, receivedCount, sentCount);
                        out.println(fullReply);
                        sentCount++;
                    }
                }
            }
        } catch (IOException e) {
            logger.log(Level.SEVERE, e.getMessage());
        } finally {
            try {
                if (serverSocket != null && !serverSocket.isClosed()) {
                    serverSocket.close();
                }
            } catch (IOException e) {
                logger.log(Level.WARNING, e.getMessage());
            }
        }
    }

    public void startClient(String serverAddress, int port) {
        try {
            clientSocket = new Socket(serverAddress, port);
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
            Scanner scanner = new Scanner(System.in);
            int sentCount = 0;
            int receivedCount = 0;

            while (sentCount < 10 && receivedCount < 10) {
                logger.log(Level.INFO, LogMessages.ENTER_MESSAGE.getValue());
                String message = scanner.nextLine();
                out.println(message);
                logger.log(Level.INFO, LogMessages.SENT_TO_SERVER.getValue() + message);

                String response = in.readLine();
                logger.log(Level.INFO, LogMessages.RECEIVED_FROM_SERVER.getValue() + response);
                receivedCount++;
            }

            logger.info(LogMessages.COMMUNICATION_COMPLETED_SHUTTING_DOWN.getValue());
            scanner.close();
        } catch (IOException e) {
            logger.log(Level.SEVERE, LogMessages.ERROR_CONNECTING_SERVER.getValue() + e.getMessage());
        } finally {
            try {
                if (clientSocket != null && !clientSocket.isClosed()) {
                    clientSocket.close();
                }
            } catch (IOException e) {
                logger.log(Level.WARNING, e.getMessage());
            }
        }
    }

    private static Properties loadProperties() {
        Properties props = new Properties();
        try (FileReader reader = new FileReader("player.properties")) {
            props.load(reader);
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Error loading properties file: " + e.getMessage());
            System.exit(0);
        }
        return props;
    }

    public static void main(String[] args) {
        Properties props = loadProperties();
        int port = Integer.parseInt(props.getProperty("player.port", "12345"));
        String serverAddress = props.getProperty("server.address", "localhost");

        Player app = new Player();
        // Start server in a new thread
        new Thread(() -> app.startServer(port)).start();
        // Start client
        app.startClient(serverAddress, port);
    }
}
